Tamefox
=======

Puts Firefox/Chromium (or any program you want) to sleep when it does not have focus.

:Requires: python-xlib python-psutil
:Usage: screen -S tamefox -d -m python tamefox.py
